import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

import 'package:titan_strong/main.dart';
import 'package:titan_strong/theme_notifier.dart';
import 'package:titan_strong/screens/splash_screen.dart';
import 'package:titan_strong/screens/login_screen.dart';
import 'package:titan_strong/screens/registration_screen.dart';


void main() {
  Widget createTestApp(Widget child) {
    return ChangeNotifierProvider(
      create: (_) => ThemeNotifier(),
      child: MaterialApp(
        home: child,
      ),
    );
  }

  group('Pantallas principales', () {
    testWidgets('SplashScreen se muestra correctamente',
        (WidgetTester tester) async {
      await tester.pumpWidget(createTestApp(const SplashScreen()));

      expect(find.text("Titan Strong"), findsOneWidget);
      expect(find.text("Iniciar Sesión"), findsOneWidget);
      expect(find.text("Registrarse"), findsOneWidget);
    });

    testWidgets('LoginScreen tiene campos de correo y contraseña',
        (WidgetTester tester) async {
      await tester.pumpWidget(createTestApp(const LoginScreen()));

      expect(find.byIcon(Icons.email), findsOneWidget);
      expect(find.byIcon(Icons.lock), findsOneWidget);
      expect(find.text("Ingresar"), findsOneWidget);
    });

    testWidgets('RegistrationScreen tiene campos de nombre, correo y contraseña',
        (WidgetTester tester) async {
      await tester.pumpWidget(createTestApp(const RegistrationScreen()));

      expect(find.byIcon(Icons.person), findsOneWidget);
      expect(find.byIcon(Icons.email), findsOneWidget);
      expect(find.byIcon(Icons.lock), findsOneWidget);
      expect(find.text("Crear cuenta"), findsOneWidget);
    });
  });

  group('App completa', () {
    testWidgets('MyApp se renderiza con SplashScreen como inicio',
        (WidgetTester tester) async {
      await tester.pumpWidget(
        ChangeNotifierProvider(
          create: (_) => ThemeNotifier(),
          child: const TitanStrongApp(),
        ),
      );

      await tester.pumpAndSettle();

      expect(find.byType(SplashScreen), findsOneWidget);
      expect(find.text("Titan Strong"), findsOneWidget);
    });
  });
}
